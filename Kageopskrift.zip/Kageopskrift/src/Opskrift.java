public class Opskrift {
//Opskrift [] ingrediensListe = new Opskrift[8];

    private Ingrediens[] opskrift;
    private int antalPersoner;
    int input = antalPersoner;

    public Opskrift(int input) {
        Ingrediens ingrediensListe1 = new Ingrediens("Smør", 100, "g", 4, 743);
        Ingrediens ingrediensListe2 = new Ingrediens("Æg", 3, " ", 4, 72, 57);
//Æg vejer 57g
        Ingrediens ingrediensListe3 = new Ingrediens("Sukker", 125, "g", 4, 500);
        Ingrediens ingrediensListe4 = new Ingrediens("vaniljestang", 0.50, " ", 4, 50, 6.5);
//vaniljestand vejer 6,5g
        Ingrediens ingrediensListe5 = new Ingrediens("hvedemel", 35, "g", 4, 25);
        Ingrediens ingrediensListe6 = new Ingrediens("salt", 0.50, "knivspids", 0, 3, 3);
//knivspids salt vejer 3g
        Ingrediens ingrediensListe7 = new Ingrediens("chokolade", 100, "g", 4, 400);
        Ingrediens ingrediensListe8 = new Ingrediens("stærk kaffe", 1, "spsk", 1, 15, 8);
//kaffe spsk vejer 8g
        opskrift = new Ingrediens[]{ingrediensListe1, ingrediensListe2, ingrediensListe3, ingrediensListe4,
                ingrediensListe5, ingrediensListe6, ingrediensListe7, ingrediensListe8};
        this.antalPersoner = input;

    }

    public Ingrediens[] getOpskrift() {
        return opskrift;
    }

    public double beregnTotalVægt() {
        double totalVægt = 0;
        for (Ingrediens ingrediens : opskrift) {
            totalVægt += ingrediens.getSamlet(antalPersoner);
        }
        return totalVægt;
    }

    public double beregnTotalKcal() {
        double totalKcal = 0;
        for (Ingrediens ingrediens : opskrift) {
            totalKcal += ingrediens.getKcal(antalPersoner);
        }
        return totalKcal;
    }

    public double beregnTotalKJ() {
        double totalKJ = 0;
        double totalKcal = 0;
        for (Ingrediens ingrediens : opskrift) {
            totalKcal += ingrediens.getKcal(antalPersoner);
            totalKJ = totalKcal * 4.2;
        }
        return totalKJ;

    }

}