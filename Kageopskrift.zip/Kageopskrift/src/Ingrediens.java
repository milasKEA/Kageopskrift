public class Ingrediens {

    //Attributes
    private String navn;
    private double mængde;
    private String enhed;
    private double vægtPerEnhed;
    private double kcal;
    private int antalPersoner;

    //Konstruktør metode

    public Ingrediens(String navn, double mængde, String enhed, int antalPersoner, double kcal) {
        this.navn = navn;
        this.mængde = mængde;
        this.enhed = enhed;
        this.antalPersoner = antalPersoner;
        this.kcal = kcal;
        vægtPerEnhed = 1;
    }

    public Ingrediens(String navn, double mængde, String enhed, int antalPersoner, double kcal, double vægtPerEnhed) {
        this.navn = navn;
        this.mængde = mængde;
        this.enhed = enhed;
        this.antalPersoner = antalPersoner;
        this.vægtPerEnhed = vægtPerEnhed;
        this.kcal = kcal;
    }

    //Set metoder
    public void setAntalPersoner(int antalPersoner) {
        this.antalPersoner = antalPersoner;

    }

    // Get metoder
    public String getNavn() {
        return navn;
    }

     public double getMængde() {
       return mængde;
}

    public String getEnhed() {
        return enhed;
    }

    public double getVægtPerEnhed() {
        return vægtPerEnhed;
    }

    public double getKcal() {
        return kcal;
    }

    public double getBeregnMængde(){
        return antalPersoner * (mængde/4);
    }

    public double getBeregnVægtPerEnhed(int antalPersoner) {
        return antalPersoner * ((vægtPerEnhed * (mængde/4)));
    }

    public double getKcal(int antalPersoner) {
        return antalPersoner * (kcal/4);
    }

    public double getSamlet(int antalPersoner){
        return (mængde/4) * antalPersoner;
    }

        public String toString() {
            return navn + mængde;
        }
    }
