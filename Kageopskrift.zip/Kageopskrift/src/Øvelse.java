public class Øvelse {
    public static void main(String[] args) {

        int age = 12;
        String nameN = "Milas";
        double weight = 72;
        boolean isCat = true;

        StringBuilder nyString = new StringBuilder();
        nyString.append(nameN);
        nyString.append(", ");
        nyString.append(weight);
        nyString.append(isCat);
        System.out.println(nyString);
    }



}
